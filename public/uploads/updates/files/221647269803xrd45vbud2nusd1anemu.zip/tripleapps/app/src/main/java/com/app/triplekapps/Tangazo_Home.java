package com.app.triplekapps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.applovin.mediation.ads.MaxInterstitialAd;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;


public class Tangazo_Home extends AppCompatActivity {

    private ProgressDialog progressDialog;

    InterstitialAd mInterstitialAd;
    SharedPreferences pref;

    private MaxInterstitialAd interstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tangazo__home);

        progressDialog = new ProgressDialog(this);

        showDialogue();

//        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
//        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
//            @Override
//            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
//            {
//                // AppLovin SDK is initialized, start loading ads
//            }
//        } );
////        StartJob();
//
//
//        interstitialAd = new MaxInterstitialAd(  getResources().getString(R.string.applovin_interstitial), this );
//        interstitialAd.setListener(new MaxAdListener() {
//            @Override
//            public void onAdLoaded(MaxAd ad) {
//                Log.e("abc","==========onAdLoaded===========");
//                ShowMaxInterstitialAd();
//                progressDialog.dismiss();
//
//            }
//
//            @Override
//            public void onAdDisplayed(MaxAd ad) {
//                Log.e("abc","==========onAdDisplayed===========");
//
//            }
//
//            @Override
//            public void onAdHidden(MaxAd ad) {
//                Log.e("abc","==========onAdHidden===========");
//
//            }
//
//            @Override
//            public void onAdClicked(MaxAd ad) {
//                Log.e("abc","==========onAdClicked===========");
//
//            }
//
//            @Override
//            public void onAdLoadFailed(String adUnitId, MaxError error) {
//                Log.e("abc","==========onAdLoadFailed===========");
//                StartJob();
//                progressDialog.dismiss();
//
//            }
//
//            @Override
//            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
//                Log.e("abc","==========onAdDisplayFailed===========");
//                StartJob();
//                progressDialog.dismiss();
//
//            }
//        });
//        interstitialAd.loadAd();


       MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {}
        });
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(this,getResources().getString(R.string.admob_interAd), adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                mInterstitialAd = interstitialAd;

                progressDialog.dismiss();

                mInterstitialAd.show(Tangazo_Home.this);

                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override
                    public void onAdDismissedFullScreenContent() {

                        StartJob();
                        // Called when fullscreen content is dismissed.
                        // Log.d("TAG", "The ad was dismissed.");
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        progressDialog.dismiss();
                        StartJob();
                        // Called when fullscreen content failed to show.
                        // Log.d("TAG", "The ad failed to show.");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
                        mInterstitialAd = null;

                        //Log.d("TAG", "The ad was shown.");

                    }
                });
                // Log.i(TAG, "onAdLoaded");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                progressDialog.dismiss();
                StartJob();
                // Handle the error
                //   Log.i(TAG, loadAdError.getMessage());
                mInterstitialAd = null;
            }
        });







//        interstitialAd = new InterstitialAd(this,getResources().getString(R.string.interstitialhome1));
//        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//                progressDialog.dismiss();
//                StartJob();
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                progressDialog.dismiss();
//                StartJob();
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                progressDialog.dismiss();
//                interstitialAd.show();
//
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        };
//
//        interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());


    }


    public void ShowMaxInterstitialAd(){

    }

    public  void StartJob(){


        Intent intent= new Intent(Tangazo_Home.this, ActivityMain.class);
        startActivity(intent);
        finish();




//        if(sharedPreferenceObj.getApp_runFirst().equals("FIRST"))
//        {
//            // That's mean First Time Launch
//            // After your Work , SET Status NO
//
////                    if(interstitialAd!=null&&interstitialAd.isAdLoaded()){
////                        interstitialAd.show();
////                    }
//        }
//        else
//        {
//
////                    if(interstitialAd!=null&&interstitialAd.isAdLoaded()){
////                        interstitialAd.show();
////                    }
//            // App is not First Time Launch
//        }
//
//
//
//
//        Intent intent = new Intent(Tangazo_Home.this, Details_Activity.class);
//        startActivity(intent);
//        finish();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }


    private void showDialogue(){
        progressDialog.setMessage("Loading Please wait.. ");
        progressDialog.setCancelable(false);
        progressDialog.show();



    }
}
