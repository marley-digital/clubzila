package com.app.triplekapps.model;

import java.io.Serializable;

public class Category implements Serializable {

    public long id = -1;
    public String slug = "";
    public String title = "";
    public String description = "";
    public long parent = -1;
    public long post_count = -1;
}
