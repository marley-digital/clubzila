package com.app.triplekapps.connection.callbacks;

import com.app.triplekapps.model.Post;

public class CallbackDetailsPost {
    public String status = "";
    public Post post = null;
}
