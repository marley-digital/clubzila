package com.app.triplekapps;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;


import com.app.triplekapps.data.AppConfig;
import com.app.triplekapps.data.GDPR;
import com.app.triplekapps.data.SharedPref;
import com.app.triplekapps.fragment.FragmentCategory;
import com.app.triplekapps.fragment.FragmentHome;
import com.app.triplekapps.fragment.FragmentLater;
import com.app.triplekapps.fragment.FragmentPage;
import com.app.triplekapps.room.AppDatabase;
import com.app.triplekapps.room.DAO;
import com.app.triplekapps.utils.Tools;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class ActivityMain extends AppCompatActivity {

    //for ads

    private Toolbar toolbar;
    private MaxAdView mymax;
    private ActionBar actionBar;
    private NavigationView navigationView;
    private DrawerLayout drawer;
    private Fragment fragment = null;
    private TextView user_name, user_email;
    private SharedPref sharedPref;
    private DAO db;
    private int notification_count = -1;
    private View notif_badge = null;

    public static MaxInterstitialAd interstitialAd;
    public static ActivityMain activityMain;
    private MaxAdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activityMain = this;
        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {

                ShowMaxBannerAd();
                // AppLovin SDK is initialized, start loading ads
            }
        } );

        db = AppDatabase.getDb(this).get();
        sharedPref = new SharedPref(this);

        loadInterstitial();

      /*  adView = new MaxAdView( getResources().getString(R.string.applovin_banner), this );
        // Stretch to the width of the screen for banners to be fully functional
        *//*int width = ViewGroup.LayoutParams.MATCH_PARENT;
        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = getResources().getDimensionPixelSize( R.dimen.banner_height );
        adView.setLayoutParams( new FrameLayout.LayoutParams( width, heightPx ,Gravity.BOTTOM) );
        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor( getResources().getColor(R.color.background_color));*//*
        ViewGroup rootView = findViewById( android.R.id.content );
        rootView.addView( adView );
        // Load the ad
        adView.loadAd();
        adView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","===========onAdExpanded====================");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===========onAdCollapsed====================");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===========onAdLoaded====================");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","===========onAdDisplayed====================");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","===========onAdHidden====================");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","===========onAdClicked====================");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===========onAdLoadFailed====================");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","===========onAdDisplayFailed====================");

            }
        });

*/

//        initBannerAds();
//        initInterstitialAds();

        initToolbar();
        initComponent();

        // get enabled controllers
        Tools.requestInfoApi(this);

       /* adView = new com.facebook.ads.AdView(this, getResources().getString(R.string.fbaanner), AdSize.BANNER_HEIGHT_90);

        // Find the Ad Container
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);

        // Add the ad view to your activity layout
        adContainer.addView(adView);

        // Request an ad
        adView.loadAd();

*/

        //Appodeal.setTesting(true);
//        Appodeal.initialize(this,getResources().getString(R.string.appodeal_app_id),Appodeal.BANNER_BOTTOM);
//        Appodeal.show(this, Appodeal.BANNER_BOTTOM);

        // display first fragment
        displayFragment(R.id.nav_home, getString(R.string.title_nav_home));

        // init GDPR
        if (AppConfig.ENABLE_GDPR) GDPR.updateConsentStatus(this);
        Tools.RTLMode(getWindow());
    }


    public void ShowMaxBannerAd(){
        MaxAdView maxBannerAdView = findViewById(R.id.MaxAdView);
        mymax = new MaxAdView(getResources().getString(R.string.applovin_banner),this);

        mymax.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });
    maxBannerAdView.addView(mymax);
    mymax.loadAd();

    }

    @Override
    protected void onDestroy() {
        /*if (adView != null) {
            adView.destroy();
        }*/
        super.onDestroy();
    }

    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }

    private void initComponent() {
        drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            public void onDrawerOpened(View drawerView) {
//                showInterstitial();
                ShowMaxInterstitialAd();

                onResume();
                super.onDrawerOpened(drawerView);
            }
        };
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                item.setChecked(true);
                displayFragment(item.getItemId(), item.getTitle().toString());
                drawer.closeDrawers();
                return true;
            }
        });

        user_name = navigationView.getHeaderView(0).findViewById(R.id.user_name);
        user_email = navigationView.getHeaderView(0).findViewById(R.id.user_email);
        View lyt_profile = (View) navigationView.getHeaderView(0).findViewById(R.id.lyt_profile);

        if (AppConfig.HIDE_PROFILE_VIEW) {
            lyt_profile.setVisibility(View.GONE);
        }

        lyt_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivitySettings.class);
                startActivity(i);
            }
        });

        (findViewById(R.id.lyt_search)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ActivitySearch.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (!drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.openDrawer(GravityCompat.START);
        } else {
            doExitApp();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        user_name.setText(sharedPref.getYourName());
        user_email.setText(sharedPref.getYourEmail());

        updateNavCounter(navigationView);
        int new_notif_count = db.getNotificationUnreadCount();
        if (new_notif_count != notification_count) {
            notification_count = new_notif_count;
            invalidateOptionsMenu();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_main, menu);
        Tools.changeMenuIconColor(menu, getResources().getColor(R.color.colorPrimary));

        final MenuItem menuItem = menu.findItem(R.id.action_notif);
        View actionView = MenuItemCompat.getActionView(menuItem);
        notif_badge = actionView.findViewById(R.id.notif_badge);

        setupBadge();

        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_notif) {
            startActivity(new Intent(getApplicationContext(), ActivityNotification.class));
        }

        return super.onOptionsItemSelected(item);
    }

    public void displayFragment(int id, String title) {
        switch (id) {
            case R.id.nav_home:
                if (!actionBar.getTitle().toString().equals(title)) {
                    actionBar.setTitle(title);
                    fragment = new FragmentHome();
                }
                break;

            case R.id.nav_category:
                if (!actionBar.getTitle().toString().equals(title)) {
                    actionBar.setTitle(title);
                    fragment = new FragmentCategory();
                }
                break;

            case R.id.nav_page:
                if (!actionBar.getTitle().toString().equals(title)) {
                    actionBar.setTitle(title);
                    fragment = new FragmentPage();
                }
                break;

            case R.id.nav_later:
                if (!actionBar.getTitle().toString().equals(title)) {
                    actionBar.setTitle(title);
                    fragment = new FragmentLater();
                }
                break;

            case R.id.nav_notification:
                startActivity(new Intent(getApplicationContext(), ActivityNotification.class));
                break;

            case R.id.nav_setting:
                startActivity(new Intent(getApplicationContext(), ActivitySettings.class));
                break;

            case R.id.nav_rate:
                Tools.rateAction(ActivityMain.this);
                break;

            case R.id.nav_more:
                Tools.directLinkToBrowserWithTime(this, getString(R.string.more_app_url));
                break;

            case R.id.nav_about:
                Tools.aboutAction(ActivityMain.this);
                break;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_content, fragment);
            fragmentTransaction.commitAllowingStateLoss();
        }
    }

    private long exitTime = 0;

    public void doExitApp() {
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(this, R.string.press_again_exit_app, Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

  /*  private void initBannerAds() {
        final AdView mAdView = findViewById(R.id.ad_view);

        mAdView.setVisibility(View.VISIBLE);
        AdRequest adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, GDPR.getBundleAd(this)).build();
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
                super.onAdLoaded();
            }
        });
    }*/

  /*  private void initInterstitialAds() {
        if (!AppConfig.ENABLE_INTERS_HOME) return;
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad_unit_id));
        AdRequest adRequest2 = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, GDPR.getBundleAd(this)).build();
        mInterstitialAd.loadAd(adRequest2);
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mInterstitialAd = null;
                        initInterstitialAds();
                    }
                }, 1000 * AppConfig.DELAY_NEXT_INTERSTITIAL);
            }
        });
    }*/

    /**
     * show ads
     */
    /*public void showInterstitial() {
        // Show the ad if it's ready
        if (AppConfig.ENABLE_ADSENSE && mInterstitialAd != null && mInterstitialAd.isLoaded() && ActivityMain.active) {
            mInterstitialAd.show();
        }
    }*/

    private void updateNavCounter(NavigationView nav) {
        Menu menu = nav.getMenu();
        // update notification counter
        int notif_count = db.getNotificationUnreadCount();
        View dot_sign = (View) menu.findItem(R.id.nav_notification).getActionView().findViewById(R.id.dot);
        if (notif_count > 0) {
            dot_sign.setVisibility(View.VISIBLE);
        } else {
            dot_sign.setVisibility(View.GONE);
        }

    }

    private void setupBadge() {
        if (notif_badge == null) return;
        notif_badge.setVisibility(notification_count == 0 ? View.INVISIBLE : View.VISIBLE);
    }

    public static boolean active = false;

    @Override
    public void onStart() {
        super.onStart();
        active = true;
    }

    @Override
    public void onStop() {
        super.onStop();
        active = false;
    }


    public static void loadInterstitial(){

        interstitialAd = new MaxInterstitialAd( activityMain.getResources().getString(R.string.applovin_interstitial), activityMain );
        interstitialAd.setListener(new MaxAdListener() {
            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","==========onAdLoaded===========");


            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","==========onAdDisplayed===========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","==========onAdHidden===========");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","==========onAdClicked===========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","==========onAdLoadFailed===========");


            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","==========onAdDisplayFailed===========");

            }
        });
        interstitialAd.loadAd();

    }

    public static void ShowMaxInterstitialAd(){
        if ( interstitialAd.isReady() )
        {
            interstitialAd.showAd();
            loadInterstitial();
        }else {
            Log.e("abc","=======AD NOT DISPLAY===ShowMaxInterstitialAd===========");


        }
    }



}
