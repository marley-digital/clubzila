package com.app.triplekapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;

public class Inter_Ad_Activity extends AppCompatActivity {
    private Button secbtn, clgbtn, unibtn , highschbtn,continuebtn;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    private String mystring ="";
   /* InterstitialAd mInterstitialAd;

    private AdView adView;
*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inter__ad_);
        secbtn = findViewById(R.id.seconday);
        clgbtn= findViewById(R.id.college);
        unibtn =findViewById(R.id.univercity);
        highschbtn = findViewById(R.id.high);
        continuebtn= findViewById(R.id.continuebtn);
        continuebtn.setBackgroundColor(getResources().getColor(R.color.grey_dark));
        PopulateButtons();
        MaxAdView maxBannerAdView = findViewById(R.id.MaxAdView);
        maxBannerAdView.loadAd();
        maxBannerAdView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });

       /* mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));

        mInterstitialAd.loadAd(new AdRequest.Builder().build());


        adView = new AdView(this, getResources().getString(R.string.fbaanner), AdSize.BANNER_HEIGHT_90);

        // Find the Ad Container
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);

        // Add the ad view to your activity layout
        adContainer.addView(adView);

        // Request an ad
        adView.loadAd();*/



    }

    private void PopulateButtons(){
        secbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clgbtn.setVisibility(View.GONE);
                unibtn.setVisibility(View.GONE);
                highschbtn.setVisibility(View.GONE);
                continuebtn.setVisibility(View.VISIBLE);
                mystring = "Secondary";


            }
        });
        clgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                unibtn.setVisibility(View.GONE);
                highschbtn.setVisibility(View.GONE);
                continuebtn.setVisibility(View.VISIBLE);
                secbtn.setVisibility(View.GONE);
                mystring= "College";

            }
        });
        unibtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clgbtn.setVisibility(View.GONE);
                highschbtn.setVisibility(View.GONE);
                continuebtn.setVisibility(View.VISIBLE);
                secbtn.setVisibility(View.GONE);
                mystring="University";

            }
        });

        highschbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clgbtn.setVisibility(View.GONE);
                unibtn.setVisibility(View.GONE);
                continuebtn.setVisibility(View.VISIBLE);
                secbtn.setVisibility(View.GONE);
                mystring="High School";

            }
        });

        continuebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences preferences = getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("edulevel", mystring);
                editor.apply();


                Intent intent = new Intent(Inter_Ad_Activity.this,Year_Activity.class);
              //  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
               /* if(mInterstitialAd.isLoaded()&&mInterstitialAd!=null){
                    mInterstitialAd.show();
                }*/

                finish();


            }
        });

    }

    @Override
    protected void onDestroy() {
       /* if (adView != null) {
            adView.destroy();
        }*/
        super.onDestroy();
    }



}
