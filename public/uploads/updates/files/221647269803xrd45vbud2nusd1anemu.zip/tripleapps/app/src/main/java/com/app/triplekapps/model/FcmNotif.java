package com.app.triplekapps.model;

import java.io.Serializable;

public class FcmNotif implements Serializable {

    public long id = -1L;
    public long post_id = -1L;
    public String title = "";
    public String content = "";
    public String image = "";

    public Notification getNotification(){
        Notification n = new Notification();
        n.id = id;
        n.post_id = post_id;
        n.title = title;
        n.content = content;
        n.image = image;
        n.read = false;
        n.created_at = System.currentTimeMillis();
        return n;
    }

}
