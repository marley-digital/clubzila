package com.app.triplekapps;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.triplekapps.adapter.AdapterComments;
import com.app.triplekapps.connection.API;
import com.app.triplekapps.connection.RestAdapter;
import com.app.triplekapps.connection.callbacks.CallbackDetailsPost;
import com.app.triplekapps.data.AppConfig;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.data.SharedPref;
import com.app.triplekapps.model.Comment;
import com.app.triplekapps.model.Post;
import com.app.triplekapps.room.AppDatabase;
import com.app.triplekapps.room.DAO;
import com.app.triplekapps.room.table.PostEntity;
import com.app.triplekapps.utils.NetworkCheck;
import com.app.triplekapps.utils.Tools;


import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.balysv.materialripple.MaterialRippleLayout;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.MediaViewListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityPostDetails extends AppCompatActivity { //} implements NativeAdListener  {

    public static final String EXTRA_OBJC = "key.EXTRA_OBJC";
    public static final String EXTRA_NOTIF = "key.EXTRA_NOTIF";
    public static final String EXTRA_LATER = "key.EXTRA_LATER";
   /* private NativeAdLayout nativeAdLayout;
    private NativeAdLayout adView;
    private NativeBannerAd nativeBannerAd;
    NativeBannerAd mNativeBannerAd;
*/
    private Button sharebtn;

   /* private com.facebook.ads.AdView banneradView;

    private InterstitialAd interstitialAd;
*/




    public static Intent navigateBase(Context context, Post obj, Boolean from_notif) {
        Intent i = new Intent(context, ActivityPostDetails.class);
        i.putExtra(EXTRA_OBJC, obj);
        i.putExtra(EXTRA_NOTIF, from_notif);
        return i;
    }

    // give preparation animation activity transition
    public static void navigate(AppCompatActivity activity, View transitionView, Post obj) {
        navigate(activity, transitionView, obj, false);
    }
    public static void navigate(AppCompatActivity activity, View transitionView, Post obj, boolean later) {
        Intent intent = new Intent(activity, ActivityPostDetails.class);
        intent.putExtra(EXTRA_OBJC, obj);
        intent.putExtra(EXTRA_LATER, later);
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(activity, transitionView, EXTRA_OBJC);
        ActivityCompat.startActivity(activity, intent, options.toBundle());
    }

    public static void navigate(AppCompatActivity activity, Post obj) {
        Intent intent = new Intent(activity, ActivityPostDetails.class);
        intent.putExtra(EXTRA_OBJC, obj);
        activity.startActivity(intent);
    }

    private Toolbar toolbar;
    private ActionBar actionBar;
    private View parent_view;
    private View lyt_parent;
    private View lyt_image_header;
    private MenuItem read_later_menu;
    private SwipeRefreshLayout swipe_refresh;
//    private com.facebook.ads.AdView fbadView;


    // extra obj
    private Post post;
    private boolean from_notif;
    private boolean from_later;

    private @Nullable
    LinearLayout adChoicesContainer;

    private int counter = 9;

  /*  private @Nullable
    NativeAdLayout nativeAdLayout1;
    private @Nullable
    com.facebook.ads.NativeAd nativeAd;*/
    private @Nullable
    AdOptionsView adOptionsView;
//    private com.facebook.ads.MediaView nativeAdMedia;

    private SharedPref sharedPref;
    private boolean flag_read_later;
    private Call<CallbackDetailsPost> callbackCall = null;

    // for fullscreen video
    private FrameLayout customViewContainer;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private View mCustomView;
    private DAO db;
    private CustomWebChromeClient customWebChromeClient;

    private MaxAdView adView;
    private AdView mAdView;

    private  MaxAdView mymax,mymax2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_details);

        db = AppDatabase.getDb(this).get();

        sharebtn = findViewById(R.id.sharebtn);

//        adView = findViewById(R.id.MaxAdView);
        AppLovinSdk.getInstance( this ).setMediationProvider( "max" );
        AppLovinSdk.initializeSdk( this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {
                ShowMaxBannerAd();
                ShowMaxBannerAd1();

            }
        } );


        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

/*

        adView = new MaxAdView( getResources().getString(R.string.applovin_banner), this );
        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = 50;
        adView.setLayoutParams( new FrameLayout.LayoutParams( width, heightPx , Gravity.TOP) );
        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor( getResources().getColor(R.color.background_color));

   */
/*     ViewGroup rootView = findViewById();
        rootView.addView( adView );*//*

        ViewGroup rootView = findViewById(android.R.id.content);

        rootView.addView(adView);
        // Load the ad
        adView.loadAd();
        adView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","=====adView======onAdExpanded====================");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","======adView=====onAdCollapsed====================");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","======adView=====onAdLoaded====================");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====adView======onAdDisplayed====================");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","======adView=====onAdHidden====================");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","=======adView====onAdClicked====================");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","=====adView======onAdLoadFailed====================");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","======adView=====onAdDisplayFailed====================");

            }
        });
*/



       /* fbadView = new com.facebook.ads.AdView(this, getResources().getString(R.string.fbaanner), AdSize.BANNER_HEIGHT_50);

        // Find the Ad Container
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);

        // Add the ad view to your activity layout
       // adContainer.addView(fbadView);

        // Request an ad
        //fbadView.loadAd();


        banneradView = new com.facebook.ads.AdView(this, getResources().getString(R.string.fbaanner), AdSize.RECTANGLE_HEIGHT_250);

        // Find the Ad Container
        LinearLayout banneradContainer = (LinearLayout) findViewById(R.id.fbbanner_container);

        // Add the ad view to your activity layout
        //banneradContainer.addView(banneradView);

        // Request an ad
        //banneradView.loadAd();

        nativeAdLayout1 = findViewById(R.id.native_ad_container);



        nativeAd = new com.facebook.ads.NativeAd(this, getResources().getString(R.string.native_id));

        NativeAdListener nativeAdListener = new NativeAdListener() {

            @Override
            public void onMediaDownloaded(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

                if (nativeAd == null || nativeAd != ad) {
                    return;
                }

                nativeAd.downloadMedia();

                if(nativeAd.isAdLoaded()){

                    if (nativeAd == null ) {
                        return;
                    }
                    // Inflate Native Ad into Container
                    inflateAd(nativeAd,nativeAdLayout1);

                }
                // Race condition, load() called again before last ad was displayed

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }

        };

        // Request an ad
        nativeAd.loadAd(
                nativeAd.buildLoadAdConfig()
                        .withAdListener(nativeAdListener)
                        .build());*/

//        nativeAd.loadAd(
//                nativeAd.buildLoadAdConfig().withAdListener(ActivityPostDetails.this).build());




        // For auto play video ads, it's recommended to load the ad
        // at least 30 seconds before it is shown


//        Appodeal.initialize(this,getResources().getString(R.string.appodeal_app_id),Appodeal.INTERSTITIAL,true);
//
//        //Appodeal.setTesting(true);
//
//        Appodeal.show(this,Appodeal.INTERSTITIAL);



        parent_view = findViewById(android.R.id.content);
        swipe_refresh = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh_layout);
        webview = (WebView) findViewById(R.id.content);
        lyt_parent = findViewById(R.id.lyt_parent);
        lyt_image_header = findViewById(R.id.lyt_image_header);

        sharedPref = new SharedPref(this);
      /*  mNativeBannerAd = new NativeBannerAd(this, getResources().getString(R.string.native_banner));

        NativeAdListener nativeAdListenerntve = new NativeAdListener() {

            @Override
            public void onMediaDownloaded(Ad ad) {
                // Native ad finished downloading all assets
                // Log.e(TAG, "Native ad finished downloading all assets.");
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                // Native ad failed to load
            }

            @Override
            public void onAdLoaded(Ad ad) {

                View adView = NativeBannerAdView.render(ActivityPostDetails.this, mNativeBannerAd, NativeBannerAdView.Type.HEIGHT_100);
                NativeAdLayout nativeBannerAdContainer = (NativeAdLayout) findViewById(R.id.native_banner_ad_container);
                // Add the Native Banner Ad View to your ad container
                nativeBannerAdContainer.addView(adView);
                // Native ad is loaded and ready to be displayed
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Native ad clicked
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Native ad impression
            }
        };

        // load the ad
        mNativeBannerAd.loadAd(
                mNativeBannerAd.buildLoadAdConfig()
                        .withAdListener(nativeAdListenerntve)
                        .build());*/


        // animation transition
        ViewCompat.setTransitionName(findViewById(R.id.image), EXTRA_OBJC);

        // get extra object
        post = (Post) getIntent().getSerializableExtra(EXTRA_OBJC);
        from_later = getIntent().getBooleanExtra(EXTRA_LATER, false);
        from_notif = getIntent().getBooleanExtra(EXTRA_NOTIF, false);
        initToolbar();

        displayPostData(true);
        // Appodeal.setTesting(true);
//        Appodeal.initialize(this,getResources().getString(R.string.appodeal_app_id),Appodeal.BANNER_BOTTOM);
//        Appodeal.show(this,Appodeal.BANNER_BOTTOM);

//        Appodeal.initialize(this,getResources().getString(R.string.appodeal_app_id),Appodeal.INTERSTITIAL);
//        Appodeal.show(this,Appodeal.INTERSTITIAL);
//
//        Appodeal.setAutoCache(Appodeal.NATIVE, false);
//       // Appodeal.setTesting(true);
//       // Appodeal.setLogLevel(Log.LogLevel.verbose);
//        Appodeal.initialize(this, getResources().getString(R.string.appodeal_app_id), Appodeal.NATIVE);
//
//        Appodeal.setNativeCallbacks(new NativeCallbacks() {
//            @Override
//            public void onNativeLoaded() {
//                showAd();
//            }
//
//            @Override
//            public void onNativeFailedToLoad() {
//
//            }
//
//            @Override
//            public void onNativeShown(NativeAd nativeAd) {
//
//            }
//
//            @Override
//            public void onNativeShowFailed(NativeAd nativeAd) {
//
//            }
//
//            @Override
//            public void onNativeClicked(NativeAd nativeAd) {
//
//            }
//
//            @Override
//            public void onNativeExpired() {
//
//            }
//        });
//
//        Appodeal.cache(this, Appodeal.NATIVE, 3);


//        prepareAds();
        sharebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = Html.fromHtml(post.title).toString() + " For more Read here ==> https://play.google.com/store/apps/details?id="+getPackageName();
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });


        if (post.isDraft() || (from_later && NetworkCheck.isConnect(this))) {
            requestAction();
        }

        // on swipe
        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                requestAction();
            }
        });

        // analytics tracking
        ThisApplication.getInstance().trackScreenView("View post : " + post.title_plain);

        Tools.RTLMode(getWindow());

    }
    @Override
    public void onDestroy() {
       /* if (mNativeBannerAd != null) {
            mNativeBannerAd.unregisterView();
            mNativeBannerAd = null;
        }*/
        super.onDestroy();
    }

    public void ShowMaxBannerAd(){
        MaxAdView maxBannerAdView = findViewById(R.id.MaxAdView);
        mymax2 = new MaxAdView(getResources().getString(R.string.applovin_interstitial),this);
        mymax2.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });

        maxBannerAdView.addView(mymax2);
        mymax2.loadAd();


    }


    public void ShowMaxBannerAd1(){
        MaxAdView maxBannerAdView1 = findViewById(R.id.MaxAdView1);
//        maxBannerAdView1.loadAd();




        mymax = new MaxAdView( getResources().getString(R.string.applovin_banner), this );
       // mymax.setListener((MaxAdViewAdListener) this);

        mymax.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });



//        // Stretch to the width of the screen for banners to be fully functional
//        int width = ViewGroup.LayoutParams.MATCH_PARENT;
//
//        // Banner height on phones and tablets is 50 and 90, respectively
//        int heightPx = getResources().getDimensionPixelSize( R.dimen.banner_height );
//
//        adView.setLayoutParams( new FrameLayout.LayoutParams( width, heightPx ) );
//
//        // Set background or background color for banners to be fully functional
//        adView.setBackgroundColor( R.color.background_color );

        maxBannerAdView1.addView(mymax);
        mymax.loadAd();
       /* maxBannerAdView1.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });
*/

    }





 /*   private void inflateAd(NativeBannerAd nativeBannerAd) {
        // Unregister last ad
        nativeBannerAd.unregisterView();

        // Add the Ad view into the ad container.
        nativeAdLayout = findViewById(R.id.native_banner_ad_container);
        LayoutInflater inflater = LayoutInflater.from(ActivityPostDetails.this);
        // Inflate the Ad view.  The layout referenced is the one you created in the last step.
        adView = (NativeAdLayout) inflater.inflate(R.layout.native_banner_ads, nativeAdLayout, false);
        nativeAdLayout.addView(adView);

        // Add the AdChoices icon
        RelativeLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(ActivityPostDetails.this, nativeBannerAd, nativeAdLayout);
        adChoicesContainer.removeAllViews();
        adChoicesContainer.addView(adOptionsView, 0);

        // Create native UI using the ad metadata.
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        MediaView nativeAdIconView = adView.findViewById(R.id.native_icon_view);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        // Set the Text.
        nativeAdCallToAction.setText(nativeBannerAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(
                nativeBannerAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeBannerAd.getAdvertiserName());
        nativeAdSocialContext.setText(nativeBannerAd.getAdSocialContext());
        sponsoredLabel.setText(nativeBannerAd.getSponsoredTranslation());

        // Register the Title and CTA button to listen for clicks.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdTitle);
        clickableViews.add(nativeAdCallToAction);
        nativeBannerAd.registerViewForInteraction(adView, nativeAdIconView, clickableViews);
    }

*/

    private void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        actionBar.setTitle("");
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
    }

    private void requestDetailsPostApi() {
        API api = RestAdapter.createAPI();
        callbackCall = api.getPostDetailsById(post.id);
        callbackCall.enqueue(new Callback<CallbackDetailsPost>() {
            @Override
            public void onResponse(Call<CallbackDetailsPost> call, Response<CallbackDetailsPost> response) {
                CallbackDetailsPost resp = response.body();
                if (resp != null && resp.status.equals("ok")) {
                    post = resp.post;
                    from_later = false;
                    displayPostData(false);
                    swipeProgress(false);
                } else {
                    onFailRequest();
                }
            }

            @Override
            public void onFailure(Call<CallbackDetailsPost> call, Throwable t) {
                if (!call.isCanceled()) onFailRequest();
            }

        });
    }

    private void requestAction() {
        showFailedView(false, "");
        swipeProgress(true);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                requestDetailsPostApi();
            }
        }, Constant.DELAY_TIME_MEDIUM);
    }

    private void onFailRequest() {
        swipeProgress(false);
        if (NetworkCheck.isConnect(this)) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.no_internet_text));
        }
    }

    private WebView webview;

    private void displayPostData(boolean is_draft) {
        customViewContainer = (FrameLayout) findViewById(R.id.customViewContainer);
        ((TextView) findViewById(R.id.title)).setText(Html.fromHtml(post.title));

        String html_data = "<style>img{max-width:100%;height:auto;} figure{max-width:100%;height:auto;} iframe{width:100%;}</style> ";
        html_data += post.content;
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setBuiltInZoomControls(true);
        webview.getSettings().setDefaultTextEncodingName("utf-8");
        webview.setBackgroundColor(Color.WHITE);
        customWebChromeClient = new CustomWebChromeClient();
        webview.setWebChromeClient(customWebChromeClient);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Tools.directLinkToBrowser(ActivityPostDetails.this, url);
                return true;
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            webview.loadDataWithBaseURL(null, html_data, "text/html; charset=UTF-8", "utf-8", null);
        } else {
            webview.loadData(html_data, "text/html; charset=UTF-8", null);
        }
        // disable scroll on touch
        webview.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return (event.getAction() == MotionEvent.ACTION_MOVE);
            }
        });

        ((TextView) findViewById(R.id.date)).setText(Tools.getFormatedDate(post.date));
        ((TextView) findViewById(R.id.comment)).setText(post.comment_count + "");
        ((TextView) findViewById(R.id.tv_comment)).setText(getString(R.string.show_tv_comments) + " (" + post.comment_count + ")");
        ((TextView) findViewById(R.id.category)).setText(Html.fromHtml(Tools.getCategoryTxt(post.categories)));
        Tools.displayImage(this, post.thumbnail, ((ImageView) findViewById(R.id.image)));
        lyt_image_header.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (URLUtil.isValidUrl(post.url)) {
                    ActivityFullScreenImage.navigate(ActivityPostDetails.this, post.thumbnail);
                }
            }
        });

        if (is_draft) {
            return;
        }
        // when show comments click
        ((MaterialRippleLayout) findViewById(R.id.bt_show_comment)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (post.comments != null && post.comments.size() <= 0) {
                    Snackbar.make(parent_view, R.string.post_have_no_comment, Snackbar.LENGTH_SHORT).show();
                    return;
                }
                dialogShowComments(post.comments);
            }
        });

        // when post comments click
        ((MaterialRippleLayout) findViewById(R.id.bt_send_comment)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!AppConfig.MUST_REGISTER_TO_COMMENT) {
                    Intent i = new Intent(ActivityPostDetails.this, ActivityWebView.class);
                    if (sharedPref.isRespondEnabled()) {
                        i = new Intent(ActivityPostDetails.this, ActivitySendComment.class);
                    }
                    i.putExtra(EXTRA_OBJC, post);
                    startActivity(i);
                } else {
                    Tools.dialogCommentNeedLogin(ActivityPostDetails.this, post.url);
                }
            }
        });

        //Snackbar.make(parent_view, R.string.post_detail_displayed_msg, Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int item_id = item.getItemId();
        if (item_id == android.R.id.home) {
            onBackPressed();
        } else if (item_id == R.id.action_share) {
            Tools.methodShare(ActivityPostDetails.this, post);
        } else if (item_id == R.id.action_later) {
            if (post.isDraft()) {
                Snackbar.make(parent_view, R.string.cannot_add_to_read_later, Snackbar.LENGTH_SHORT).show();
                return true;
            }
            String str;
            if (flag_read_later) {
                db.deletePost(post.id);
                str = getString(R.string.remove_from_msg);
            } else {
                db.insertPost(PostEntity.entity(post));
                str = getString(R.string.added_to_msg);
            }
            Snackbar.make(parent_view, "Post " + str + " Read Later", Snackbar.LENGTH_SHORT).show();
            refreshReadLaterMenu();
        } else if (item_id == R.id.action_browser) {
            Tools.directLinkToBrowser(this, post.url);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.menu_activity_post_details, menu);
        Tools.changeMenuIconColor(menu, getResources().getColor(R.color.colorPrimary));
        read_later_menu = menu.findItem(R.id.action_later);
        refreshReadLaterMenu();
        return true;
    }

    private void dialogShowComments(List<Comment> items) {
        if(items == null ) items = new ArrayList<>();
        final Dialog dialog = new Dialog(ActivityPostDetails.this);
        dialog.setCancelable(true);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_comments);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        RecyclerView recyclerView = (RecyclerView) dialog.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        AdapterComments mAdapter = new AdapterComments(this, items);
        recyclerView.setAdapter(mAdapter);

        ((ImageView) dialog.findViewById(R.id.img_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    private void refreshReadLaterMenu() {
        flag_read_later = db.getPost(post.id) != null;
        Drawable drawable = read_later_menu.getIcon();
        if (flag_read_later) {
            drawable.setColorFilter(getResources().getColor(R.color.grey_60), PorterDuff.Mode.SRC_ATOP);
        } else {
            drawable.setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
        }
    }

  /*  private void prepareAds() {
        final AdView mAdView = findViewById(R.id.ad_view);
        mAdView.setVisibility(View.VISIBLE);
        AdRequest adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, GDPR.getBundleAd(this)).build();
        mAdView.loadAd(adRequest);
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdView.setVisibility(View.VISIBLE);
                super.onAdLoaded();
            }
        });
    }*/

    private void showFailedView(boolean show, String message) {
        View lyt_failed = (View) findViewById(R.id.lyt_failed);
        View lyt_main_content = (View) findViewById(R.id.lyt_main_content);

        ((TextView) findViewById(R.id.failed_message)).setText(message);
        if (show) {
            lyt_main_content.setVisibility(View.GONE);
            lyt_failed.setVisibility(View.VISIBLE);
        } else {
            lyt_main_content.setVisibility(View.VISIBLE);
            lyt_failed.setVisibility(View.GONE);
        }
        ((Button) findViewById(R.id.failed_retry)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction();
            }
        });
    }

    private void swipeProgress(final boolean show) {
        if (!show) {
            swipe_refresh.setRefreshing(show);
            return;
        }
        swipe_refresh.post(new Runnable() {
            @Override
            public void run() {
                swipe_refresh.setRefreshing(show);
            }
        });
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        webview.onResume();
        super.onResume();
    }

    @Override
    protected void onPause() {
        webview.onPause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mCustomView != null) {
            customWebChromeClient.onHideCustomView();
        }
    }

   /* private void inflateAd(com.facebook.ads.NativeAd nativeAd, View adView) {
        //Log.d(TAG, "Aspect ratio of ad: " + nativeAd.getAspectRatio());

        // Create native UI using the ad metadata.
        MediaView nativeAdIcon = adView.findViewById(R.id.native_ad_icon);
        TextView nativeAdTitle = adView.findViewById(R.id.native_ad_title);
        TextView nativeAdBody = adView.findViewById(R.id.native_ad_body);
        TextView sponsoredLabel = adView.findViewById(R.id.native_ad_sponsored_label);
        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        Button nativeAdCallToAction = adView.findViewById(R.id.native_ad_call_to_action);

        nativeAdMedia = adView.findViewById(R.id.native_ad_media);
        nativeAdMedia.setListener(getMediaViewListener());

        LinearLayout adChoicesContainer = findViewById(R.id.ad_choices_container);
        AdOptionsView adOptionsView = new AdOptionsView(ActivityPostDetails.this, nativeAd, nativeAdLayout1);
        adChoicesContainer.removeAllViews();
        adChoicesContainer.addView(adOptionsView, 0);

        // Setting the Text
        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
        nativeAdTitle.setText(nativeAd.getAdvertiserName());
        nativeAdBody.setText(nativeAd.getAdBodyText());
        sponsoredLabel.setText("Sponsored");

        // You can use the following to specify the clickable areas.
        List<View> clickableViews = new ArrayList<>();
        clickableViews.add(nativeAdIcon);
        clickableViews.add(nativeAdMedia);
        clickableViews.add(nativeAdCallToAction);
        nativeAd.registerViewForInteraction(
                nativeAdLayout1, nativeAdMedia, nativeAdIcon, clickableViews);

        // Optional: tag views
        NativeAdBase.NativeComponentTag.tagView(nativeAdIcon, NativeAdBase.NativeComponentTag.AD_ICON);
        NativeAdBase.NativeComponentTag.tagView(nativeAdTitle, NativeAdBase.NativeComponentTag.AD_TITLE);
        NativeAdBase.NativeComponentTag.tagView(nativeAdBody, NativeAdBase.NativeComponentTag.AD_BODY);
        NativeAdBase.NativeComponentTag.tagView(nativeAdSocialContext, NativeAdBase.NativeComponentTag.AD_SOCIAL_CONTEXT);
        NativeAdBase.NativeComponentTag.tagView(nativeAdCallToAction, NativeAdBase.NativeComponentTag.AD_CALL_TO_ACTION);
    }
*/
    private static MediaViewListener getMediaViewListener() {
        return new MediaViewListener() {
            @Override
            public void onVolumeChange(MediaView mediaView, float volume) {
                //Log.i(TAG, "MediaViewEvent: Volume " + volume);
            }

            @Override
            public void onPause(MediaView mediaView) {
                //  Log.i(TAG, "MediaViewEvent: Paused");
            }

            @Override
            public void onPlay(MediaView mediaView) {
                // Log.i(TAG, "MediaViewEvent: Play");
            }

            @Override
            public void onFullscreenBackground(MediaView mediaView) {
                //Log.i(TAG, "MediaViewEvent: FullscreenBackground");
            }

            @Override
            public void onFullscreenForeground(MediaView mediaView) {
                //  Log.i(TAG, "MediaViewEvent: FullscreenForeground");
            }

            @Override
            public void onExitFullscreen(MediaView mediaView) {
                //  Log.i(TAG, "MediaViewEvent: ExitFullscreen");
            }

            @Override
            public void onEnterFullscreen(MediaView mediaView) {
                //  Log.i(TAG, "MediaViewEvent: EnterFullscreen");
            }

            @Override
            public void onComplete(MediaView mediaView) {
                // Log.i(TAG, "MediaViewEvent: Completed");
            }
        };
    }






    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (mCustomView != null) {
                customWebChromeClient.onHideCustomView();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
/*

    @Override
    public void onMediaDownloaded(Ad ad) {

    }

    @Override
    public void onError(Ad ad, AdError adError) {

    }

    @Override
    public void onAdLoaded(Ad ad) {

        if (nativeAd == null || nativeAd != ad) {
            // Race condition, load() called again before last ad was displayed
            return;
        }

        if (nativeAdLayout == null) {
            return;
        }

        // Unregister last ad
        nativeAd.unregisterView();



        if (!nativeAd.isAdLoaded() || nativeAd.isAdInvalidated()) {

            return;
        }

        if (adChoicesContainer != null) {
            adOptionsView = new AdOptionsView(this, nativeAd, nativeAdLayout);
            adChoicesContainer.removeAllViews();
            adChoicesContainer.addView(adOptionsView, 0);
        }

        inflateAd(nativeAd, nativeAdLayout1);

        // Registering a touch listener to log which ad component receives the touch event.
        // We always return false from onTouch so that we don't swallow the touch event (which
        // would prevent click events from reaching the NativeAd control).
        // The touch listener could be used to do animations.
        nativeAd.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent event) {
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            int i = view.getId();

                        }
                        return false;
                    }
                });


    }

    @Override
    public void onAdClicked(Ad ad) {

    }

    @Override
    public void onLoggingImpression(Ad ad) {

    }
*/


    class CustomWebChromeClient extends WebChromeClient {
        private View mVideoProgressView;

        @Override
        public void onShowCustomView(View view, int requestedOrientation, CustomViewCallback callback) {
            onShowCustomView(view, callback);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            // if a view already exists then immediately terminate the new one
            if (mCustomView != null) {
                callback.onCustomViewHidden();
                return;
            }
            // landscape and fullscreen
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            Tools.toggleFullScreenActivity(ActivityPostDetails.this, true);

            mCustomView = view;
            lyt_parent.setVisibility(View.GONE);
            customViewContainer.setVisibility(View.VISIBLE);
            customViewContainer.addView(view);
            customViewCallback = callback;
        }

        @Override
        public View getVideoLoadingProgressView() {
            if (mVideoProgressView == null) {
                LayoutInflater inflater = LayoutInflater.from(ActivityPostDetails.this);
                mVideoProgressView = inflater.inflate(R.layout.video_progress, null);
            }
            return mVideoProgressView;
        }

        @Override
        public void onHideCustomView() {
            super.onHideCustomView();
            if (mCustomView == null) return;

            // revert landscape and fullscreen
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            Tools.toggleFullScreenActivity(ActivityPostDetails.this, false);

            lyt_parent.setVisibility(View.VISIBLE);
            customViewContainer.setVisibility(View.GONE);

            // Hide the custom view.
            mCustomView.setVisibility(View.GONE);

            // Remove the custom view from its container.
            customViewContainer.removeView(mCustomView);
            customViewCallback.onCustomViewHidden();

            mCustomView = null;
        }
    }

}