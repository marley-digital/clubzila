package com.app.triplekapps.room.table;

import com.app.triplekapps.model.Notification;
import com.google.gson.annotations.Expose;

import java.io.Serializable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "notification")
public class NotificationEntity implements Serializable {

    @PrimaryKey
    public Long id;

    @Expose
    @ColumnInfo(name = "title")
    public String title;

    @Expose
    @ColumnInfo(name = "content")
    public String content;

    @Expose
    @ColumnInfo(name = "post_id")
    public Long post_id;

    @Expose
    @ColumnInfo(name = "image")
    public String image;

    @Expose
    @ColumnInfo(name = "read")
    public Boolean read = false;

    @Expose
    @ColumnInfo(name = "created_at")
    public Long created_at;

    public NotificationEntity() {
    }

    public static NotificationEntity entity(Notification notification) {
        NotificationEntity entity = new NotificationEntity();
        entity.id = notification.id;
        entity.title = notification.title;
        entity.content = notification.content;
        entity.post_id = notification.post_id;
        entity.image = notification.image;
        entity.read = notification.read;
        entity.created_at = notification.created_at;
        return entity;
    }
}
