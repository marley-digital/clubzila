package com.app.triplekapps.utils;

import android.content.Context;

import com.app.triplekapps.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

public class Ads {

    private final Context context;
    public InterstitialAd mInterstitialAd;
        public com.facebook.ads.InterstitialAd fbinterAd;

        public Ads(Context context){
            this.context  = context;

        }

        public void LoadAdmobInterAd(Context context) {
            MobileAds.initialize(context,
                    context.getResources().getString(R.string.admob_app_id));

            mInterstitialAd = new InterstitialAd(context);
//            mInterstitialAd.setAdUnitId(context.getResources().getString(R.string.interstitial_ad_unit_id));

            mInterstitialAd.loadAd(new AdRequest.Builder().build());

        }

        public  void ShowInterAdAdmob(){

            if(mInterstitialAd.isLoaded()){

                mInterstitialAd.show();


            }


        }

        public  void loadfbAd(Context context, String string){

            fbinterAd =  new com.facebook.ads.InterstitialAd(context,string);
            fbinterAd.loadAd();

        }



    }

