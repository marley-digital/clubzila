package com.app.triplekapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.app.triplekapps.ActivityMain.ShowMaxInterstitialAd;

public class Summary_Activity extends AppCompatActivity {
    Button btn4;
    TextView summary;
    String ujumbe;
//    InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_);
        btn4 = findViewById(R.id.continuebtn4);
        SharedPreferences prefs =getApplicationContext().getSharedPreferences("MyPrefsFile", MODE_PRIVATE);
        String name = prefs.getString("myname", null);//"No name defined" is the default value.
        String graduyear =prefs.getString("graduyear",null);
        String edulevel = prefs.getString("edulevel",null);

        summary =findViewById(R.id.helltotxt);

/*

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));

        mInterstitialAd.loadAd(new AdRequest.Builder().build());
*/

        ujumbe ="Hello Friend ,  we are going to suggest job for you according to the information you filled here, "
                 + " Please Press Continue button below";
        summary.setText(ujumbe);


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Summary_Activity.this, ActivityMain.class);
                startActivity(intent);

                ShowMaxInterstitialAd();

/*
                if(mInterstitialAd.isLoaded()&&mInterstitialAd!=null){
                    mInterstitialAd.show();
                }*/
               // finish();
            }
        });
    }
}
