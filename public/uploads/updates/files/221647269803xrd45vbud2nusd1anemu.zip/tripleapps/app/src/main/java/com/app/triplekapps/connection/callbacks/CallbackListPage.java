package com.app.triplekapps.connection.callbacks;

import com.app.triplekapps.model.Page;

import java.util.ArrayList;
import java.util.List;

public class CallbackListPage {

    public String status = "";
    public int count = -1;
    public int count_total = -1;
    public int pages = -1;
    public List<Page> posts = new ArrayList<>();
}
