package com.app.triplekapps.room;

import com.app.triplekapps.room.table.NotificationEntity;
import com.app.triplekapps.room.table.PostEntity;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface DAO {

    /* table post transaction ------------------------------------------------------------------ */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertPost(PostEntity post);

    @Query("DELETE FROM post WHERE id = :id")
    void deletePost(long id);

    @Query("DELETE FROM post")
    void deleteAllPost();

    @Query("SELECT * FROM post ORDER BY saved_date DESC")
    List<PostEntity> getAllPost();

    @Query("SELECT COUNT(id) FROM post")
    Integer getPostCount();

    @Query("SELECT * FROM post WHERE id = :id LIMIT 1")
    PostEntity getPost(long id);

    /* table notification transaction ----------------------------------------------------------- */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertNotification(NotificationEntity notification);

    @Query("DELETE FROM notification WHERE id = :id")
    void deleteNotification(long id);

    @Query("DELETE FROM notification")
    void deleteAllNotification();

    @Query("SELECT * FROM notification ORDER BY created_at DESC LIMIT :limit OFFSET :offset")
    List<NotificationEntity> getNotificationByPage(int limit, int offset);

    @Query("SELECT * FROM notification WHERE id = :id LIMIT 1")
    NotificationEntity getNotification(long id);

    @Query("SELECT COUNT(id) FROM notification WHERE read = 0")
    Integer getNotificationUnreadCount();

    @Query("SELECT COUNT(id) FROM notification")
    Integer getNotificationCount();
}
