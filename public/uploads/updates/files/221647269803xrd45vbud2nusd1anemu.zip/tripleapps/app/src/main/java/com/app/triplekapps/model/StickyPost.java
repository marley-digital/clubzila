package com.app.triplekapps.model;

import java.util.ArrayList;
import java.util.List;

public class StickyPost {

    public List<Post> posts = new ArrayList<>();

    public StickyPost() {
    }

    public StickyPost(List<Post> posts) {
        this.posts = posts;
    }

}
