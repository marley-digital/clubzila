package com.app.triplekapps.model;

public class Notification {
    public Long id = -1L;
    public String title = "";
    public String content ="";
    public Long post_id = -1L;
    public String image = "";
    public Boolean read = false;
    public Long created_at = -1L;
}
