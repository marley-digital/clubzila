package com.app.triplekapps.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.triplekapps.ActivityMain;
import com.app.triplekapps.ActivityPostDetails;
import com.app.triplekapps.R;
import com.app.triplekapps.adapter.AdapterPostList;
import com.app.triplekapps.model.Post;
import com.app.triplekapps.room.AppDatabase;
import com.app.triplekapps.room.DAO;
import com.app.triplekapps.room.table.PostEntity;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FragmentLater extends Fragment {

    private View root_view, parent_view;
    private RecyclerView recyclerView;
    private AdapterPostList mAdapter;
    private DAO db;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root_view = inflater.inflate(R.layout.fragment_later, null);

        parent_view = getActivity().findViewById(R.id.main_content);
        db = AppDatabase.getDb(getContext()).get();

        recyclerView = root_view.findViewById(R.id.recyclerViewLater);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        //set data and list adapter
        mAdapter = new AdapterPostList(getActivity(), recyclerView, new ArrayList<Post>());
        recyclerView.setAdapter(mAdapter);

        // on item list clicked
        mAdapter.setOnItemClickListener(new AdapterPostList.OnItemClickListener() {
            @Override
            public void onItemClick(View v, Post obj, int position) {
                ActivityPostDetails.navigate((ActivityMain) getActivity(), v.findViewById(R.id.image), obj, true);
            }
        });

        return root_view;
    }

    @Override
    public void onResume() {
        super.onResume();
        displayData(db.getAllPost());
    }

    private void displayData(final List<PostEntity> posts) {
        List<Post> items = new ArrayList<>();
        for (PostEntity p : posts) items.add(p.original());
        showNoItemView(false);
        mAdapter.resetListData();
        mAdapter.insertData(items);
        if (posts.size() == 0) {
            showNoItemView(true);
        }
    }

    private void showNoItemView(boolean show) {
        View lyt_no_item = (View) root_view.findViewById(R.id.lyt_no_item_later);
        ((TextView) root_view.findViewById(R.id.no_item_message)).setText(R.string.no_post);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            lyt_no_item.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            lyt_no_item.setVisibility(View.GONE);
        }
    }
}
