package com.app.triplekapps.data;

public class Constant {

    // your wordpress URL
    public static String WORDPRESS_URL = "https://trippleapps.com/";

    /* This string must be same with security code menu FCM > Settings */
    public static final String SECURITY_CODE = "8V06LupAaMBLtQqyqTxmcN42nn27FlejvaoSM3zXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    // show post & page per request
    public static int POST_PER_REQUEST = 10;
    public static int PAGE_PER_REQUEST = 10;
    public static int PAGE_NOTIFICATION = 20;

    // delay for better user experience (millisecond)
    public static long DELAY_TIME = 100;
    public static long DELAY_TIME_MEDIUM = 500;
    public static long DELAY_TIME_LONG = 1000;
    public static long DELAY_TIME_SPLASH = 1500;

    // max search result
    public static int MAX_SEARCH_RESULT = 10;

    // retry load image notification
    public static int LOAD_IMAGE_NOTIF_RETRY = 3;

}
