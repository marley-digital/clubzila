package com.app.triplekapps.fcm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;

import com.app.triplekapps.ActivityDialogNotification;
import com.app.triplekapps.R;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.data.SharedPref;
import com.app.triplekapps.model.FcmNotif;
import com.app.triplekapps.room.AppDatabase;
import com.app.triplekapps.room.table.NotificationEntity;
import com.app.triplekapps.utils.CallbackImageNotif;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.Map;

import androidx.core.app.NotificationCompat;

public class FcmMessagingService extends FirebaseMessagingService {

    private static int VIBRATION_TIME = 500; // in millisecond
    private SharedPref sharedPref;
    private int retry_count = 0;

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        sharedPref = new SharedPref(this);
        sharedPref.setFcmRegId(s);
        sharedPref.setOpenAppCounter(SharedPref.MAX_OPEN_COUNTER);
        sharedPref.setSubscibeNotif(false);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        sharedPref = new SharedPref(this);
        retry_count = 0;
        if (!sharedPref.getNotification()) return;
        FcmNotif fcmNotif = new FcmNotif();
        fcmNotif.id = System.currentTimeMillis();
        if (remoteMessage.getData().size() > 0) {
            Map<String, String> data = remoteMessage.getData();
            fcmNotif.post_id = data.get("post_id") == null ? -1 : Integer.parseInt(data.get("post_id"));
            fcmNotif.title = data.get("title");
            fcmNotif.content = data.get("content");
            fcmNotif.image = data.get("image");
        } else if (remoteMessage.getNotification() != null) {
            RemoteMessage.Notification rn = remoteMessage.getNotification();
            fcmNotif.title = rn.getTitle();
            fcmNotif.content = rn.getBody();
        }
        if (TextUtils.isEmpty(fcmNotif.title)) return;
        // save to database
        NotificationEntity entity = NotificationEntity.entity(fcmNotif.getNotification());
        AppDatabase.getDb(this).get().insertNotification(entity);

        // display notification
        prepareImageNotification(fcmNotif);
    }

    private void prepareImageNotification(final FcmNotif fcmNotif) {
        if (fcmNotif.image != null && !fcmNotif.image.equals("")) {
            loadImageFromUrl(this, fcmNotif.image, new CallbackImageNotif() {
                @Override
                public void onSuccess(Bitmap bitmap) {
                    displayNotificationIntent(fcmNotif, bitmap);
                }

                @Override
                public void onFailed(String string) {
                    Log.e("onFailed", string);
                    if (retry_count <= Constant.LOAD_IMAGE_NOTIF_RETRY) {
                        retry_count++;
                        prepareImageNotification(fcmNotif);
                    } else {
                        displayNotificationIntent(fcmNotif, null);
                    }
                }
            });
        } else {
            displayNotificationIntent(fcmNotif, null);
        }
    }

    private void displayNotificationIntent(FcmNotif fcmNotif, Bitmap bitmap) {

        NotificationEntity entity = NotificationEntity.entity(fcmNotif.getNotification());
        Intent intent = ActivityDialogNotification.navigateBase(this, entity, true);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, (int) System.currentTimeMillis(), intent, 0);

        String channelId = getString(R.string.default_notification_channel_id);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
        builder.setContentTitle(Html.fromHtml(fcmNotif.title));
        builder.setStyle(new NotificationCompat.BigTextStyle().bigText(Html.fromHtml(fcmNotif.content)));
        builder.setContentText(Html.fromHtml(fcmNotif.content));
        builder.setSmallIcon(R.drawable.ic_notification);
        builder.setDefaults(Notification.DEFAULT_LIGHTS);
        builder.setContentIntent(pendingIntent);
        builder.setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            builder.setPriority(Notification.PRIORITY_HIGH);
        }

        builder.setStyle(new NotificationCompat.BigTextStyle().bigText(Html.fromHtml(fcmNotif.content)));
        if (bitmap != null) {
            builder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bitmap).setSummaryText(Html.fromHtml(fcmNotif.content)));
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelId, NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(channel);
        }
        int unique_id = (int) System.currentTimeMillis();
        notificationManager.notify(unique_id, builder.build());
        playVibrationAndRingtone();
    }

    private void playVibrationAndRingtone() {
        try {
            // play vibration
            if (sharedPref.getVibration()) {
                ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).vibrate(VIBRATION_TIME);
            }
        } catch (Exception e) {
        }
        try {
            RingtoneManager.getRingtone(this, Uri.parse(sharedPref.getRingtone())).play();
        } catch (Exception e) {
        }
    }

    // load image with callback
    Handler mainHandler = new Handler(Looper.getMainLooper());
    Runnable myRunnable;

    private void loadImageFromUrl(final Context ctx, final String url, final CallbackImageNotif callback) {
        Log.e("Func", "loadImageFromUrl");
        myRunnable = new Runnable() {
            @Override
            public void run() {
                Picasso.get().load(url).into(new Target() {
                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                        callback.onSuccess(bitmap);
                    }

                    @Override
                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                    }



                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {

                    }
                });
            }
        };
        mainHandler.post(myRunnable);
    }

}
