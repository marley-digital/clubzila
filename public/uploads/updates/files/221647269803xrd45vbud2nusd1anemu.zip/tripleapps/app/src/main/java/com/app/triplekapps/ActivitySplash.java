package com.app.triplekapps;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.app.triplekapps.data.Constant;
import com.app.triplekapps.utils.Tools;

import androidx.appcompat.app.AppCompatActivity;

public class ActivitySplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        startNextActivity();
        Tools.setSystemBarColor(this, android.R.color.white);
        Tools.setSystemBarLight(this);
        Tools.RTLMode(getWindow());
       // Appodeal.setTesting(true);


    }

    // make a delay to start next activity
    private void startNextActivity() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ActivitySplash.this.finish();
                Intent i = new Intent(getApplicationContext(),Tangazo_Home.class);
                startActivity(i);

             // Appodeal.show(ActivitySplash.this,Appodeal.INTERSTITIAL);

            }
        }, Constant.DELAY_TIME_SPLASH);
    }
}
