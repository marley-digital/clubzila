package com.app.triplekapps.model;

import java.io.Serializable;

public class Author implements Serializable {

    public long id = -1;
    public String slug = "";
    public String name = "";
    public String first_name = "";
    public String last_name = "";
    public String nickname = "";
    public String url = "";
    public String description = "";

}
