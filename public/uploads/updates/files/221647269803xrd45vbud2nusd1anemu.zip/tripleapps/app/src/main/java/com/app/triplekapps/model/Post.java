package com.app.triplekapps.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Post implements Serializable {

    public long id = -1;
    public String type = "";
    public String slug = "";
    public String url = "";
    public String status = "";
    public String title = "";
    public String title_plain = "";
    public String content = "";
    public String excerpt = "";
    public String date = "";
    public String modified = "";
    public String thumbnail = "";
    public long comment_count = -1;

    public Post() {
    }

    public Post(long id) {
        this.id = id;
    }

    public List<Category> categories = new ArrayList<>();
    public Author author = null;
    public List<Comment> comments = new ArrayList<>();

    public boolean isDraft() {
        return content == null || content.trim().equals("");
    }

}
