package com.app.triplekapps;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;

import java.util.Calendar;

import static com.app.triplekapps.ActivityMain.ShowMaxInterstitialAd;

public class Year_Activity extends AppCompatActivity {

    private Calendar calendar;
    private TextView myyear;
    private Button cntnue2;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    private String mystring ="";

//    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_year);
        myyear = findViewById(R.id.myyear);
        calendar = Calendar.getInstance();

      /*  interstitialAd = new com.facebook.ads.InterstitialAd(this,getResources().getString(R.string.interitialhome2));
         interstitialAd.loadAd();
*/

        cntnue2= findViewById(R.id.continuebtn2);
        MaxAdView maxBannerAdView = findViewById(R.id.MaxAdView);
        maxBannerAdView.loadAd();
        maxBannerAdView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });


        mystring = myyear.getText().toString();

        cntnue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences = getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
               // SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                editor.putString("graduyear", mystring);
                editor.apply();
                Intent intent= new Intent(Year_Activity.this,Details_Activity.class);
                startActivity(intent);

                ShowMaxInterstitialAd();

              /*  if(interstitialAd!=null&&interstitialAd.isAdLoaded()){
                    interstitialAd.show();
                }*/
               // finish();

            }
        });
        myyear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showBirthDayPicker();
            }
        });

    }

    @Override
    protected void onDestroy() {
     /*   if (interstitialAd != null) {
            interstitialAd.destroy();
        }*/
        super.onDestroy();
    }

    private void showBirthDayPicker() {
        int year = calendar.get(Calendar.YEAR);

        final Dialog birthDayDialog = new Dialog(this);
        birthDayDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        birthDayDialog.setContentView(R.layout.dialog_single_number_picker);

        Button okBtn = birthDayDialog.findViewById(R.id.btn_ok);
        Button cancelBtn = birthDayDialog.findViewById(R.id.btn_cancel);


        final NumberPicker np = birthDayDialog.findViewById(R.id.birthdayPicker);
        np.setMinValue(year - 50);
        np.setMaxValue(year + 1);
        np.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
     //   setDivider(np, android.R.color.white);
        np.setWrapSelectorWheel(false);
        np.setValue(year-20);
        np.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {

            }
        });

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myyear.setText(String.valueOf(np.getValue()));
                birthDayDialog.dismiss();
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                birthDayDialog.dismiss();
            }
        });

        birthDayDialog.show();
    }
}
