package com.app.triplekapps.connection.callbacks;

import com.app.triplekapps.model.Page;

public class CallbackDetailsPage {
    public String status = "";
    public Page page = null;
}
