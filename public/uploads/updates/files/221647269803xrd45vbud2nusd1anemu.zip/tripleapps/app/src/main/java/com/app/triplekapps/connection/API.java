package com.app.triplekapps.connection;


import com.app.triplekapps.connection.callbacks.CallbackCategories;
import com.app.triplekapps.connection.callbacks.CallbackCategoryDetails;
import com.app.triplekapps.connection.callbacks.CallbackComment;
import com.app.triplekapps.connection.callbacks.CallbackDetailsPage;
import com.app.triplekapps.connection.callbacks.CallbackDetailsPost;
import com.app.triplekapps.connection.callbacks.CallbackDevice;
import com.app.triplekapps.connection.callbacks.CallbackInfo;
import com.app.triplekapps.connection.callbacks.CallbackListPage;
import com.app.triplekapps.connection.callbacks.CallbackListPost;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.model.DeviceInfo;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface API {

    String BASE_URL = Constant.WORDPRESS_URL;

    // minimize field for list of post
    String EXCLUDE_FIELD = "&exclude=content,categories,tags,comments,custom_fields,attachments,thumbnail_images";
    String CACHE = "Cache-Control: max-age=0";
    String AGENT = "User-Agent: Koran";
    String SECURITY = "Security: " + Constant.SECURITY_CODE;

    /* info API transaction ------------------------------- */

    @GET("?json=info")
    Call<CallbackInfo> getInfo();


    /* Post API transaction ------------------------------- */

    @Headers({CACHE, AGENT})
    @GET("?json=get_posts" + EXCLUDE_FIELD)
    Call<CallbackListPost> getPostByPage(
            @Query("page") int page,
            @Query("count") int count
    );

    @Headers({CACHE, AGENT})
    @GET("?json=get_posts&sticky=true&page=1&count=50" + EXCLUDE_FIELD)
    Call<CallbackListPost> getStickyPost();

    @Headers({CACHE, AGENT})
    @GET("?json=get_post")
    Call<CallbackDetailsPost> getPostDetailsById(
            @Query("id") long id
    );

    @Headers({CACHE, AGENT})
    @GET("?json=get_search_results" + EXCLUDE_FIELD)
    Call<CallbackListPost> getSearchPosts(
            @Query("search") String search,
            @Query("page") int page,
            @Query("count") int count
    );


    /* Category API transaction --------------------------- */

    @Headers({CACHE, AGENT})
    @GET("?json=get_category_index")
    Call<CallbackCategories> getAllCategories();

    @Headers({CACHE, AGENT})
    @GET("?json=get_category_posts" + EXCLUDE_FIELD)
    Call<CallbackCategoryDetails> getCategoryDetailsByPage(
            @Query("id") long id,
            @Query("page") long page,
            @Query("count") long count
    );

    @Headers({CACHE, AGENT})
    @GET("?json=respond/submit_comment")
    Call<CallbackComment> sendComment(
            @Query("post_id") long post_id,
            @Query("name") String name,
            @Query("email") String email,
            @Query("content") String content
    );

    /* Page API transaction --------------------------- */

    @Headers({CACHE, AGENT})
    @GET("?json=get_pages" + EXCLUDE_FIELD)
    Call<CallbackListPage> getPagesByPage(
            @Query("page") int page,
            @Query("count") int count,
            @Query(value = "include_ids", encoded = true) String include_ids,
            @Query(value = "exclude_ids", encoded = true) String exclude_ids
    );

    @Headers({CACHE, AGENT})
    @GET("?json=get_page")
    Call<CallbackDetailsPage> getPageDetailsById(
            @Query("id") long id
    );

    /* FCM notification API transaction --------------------------- */

    @Headers({CACHE, AGENT, SECURITY})
    @POST("?api-fcm=register")
    Call<CallbackDevice> registerDevice(@Body DeviceInfo deviceInfo);


}
