package com.app.triplekapps.model;

import java.io.Serializable;

public class DeviceInfo implements Serializable {
    public String regid;
    public String serial;
    public String device_name;
    public String os_version;
}
