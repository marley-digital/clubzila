package com.app.triplekapps;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.app.triplekapps.adapter.AdapterPostList;
import com.app.triplekapps.adapter.AdapterSuggestionSearch;
import com.app.triplekapps.connection.API;
import com.app.triplekapps.connection.RestAdapter;
import com.app.triplekapps.connection.callbacks.CallbackListPost;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.model.Page;
import com.app.triplekapps.model.Post;
import com.app.triplekapps.utils.NetworkCheck;
import com.app.triplekapps.utils.Tools;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivitySearch extends AppCompatActivity {

    private Toolbar toolbar;
    private ActionBar actionBar;
    private EditText et_search;

    private RecyclerView recyclerView;
    private AdapterPostList mAdapter;

    private RecyclerView recyclerSuggestion;
    private AdapterSuggestionSearch mAdapterSuggestion;
    private LinearLayout lyt_suggestion;

    private ImageButton bt_clear;
    private ProgressBar progressBar;
    private View parent_view;
    private Call<CallbackListPost> callbackCall = null;
    private Snackbar failed_snackbar;

    private String query;
    private int post_total = 0;
    private int failed_page = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        parent_view = findViewById(android.R.id.content);

        initComponent();
        initToolbar();

        MaxAdView maxBannerAdView = findViewById(R.id.MaxAdView);
        maxBannerAdView.loadAd();
        maxBannerAdView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {
                Log.e("abc","====MaxAdView=====onAdExpanded===========");
            }

            @Override
            public void onAdCollapsed(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdCollapsed==============");

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
                Log.e("abc","===MaxAdView===onAdLoaded==============");

            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
                Log.e("abc","=====MaxAdView=====onAdDisplayed==========");

            }

            @Override
            public void onAdHidden(MaxAd ad) {
                Log.e("abc","=====MaxAdView===onAdHidden============");

            }

            @Override
            public void onAdClicked(MaxAd ad) {
                Log.e("abc","======MaxAdView====onAdClicked==========");

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {
                Log.e("abc","===MaxAdView====onAdLoadFailed=============");

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                Log.e("abc","=====MaxAdView===onAdDisplayFailed============");

            }
        });



        Tools.RTLMode(getWindow());
    }

    private void initComponent() {
        lyt_suggestion = (LinearLayout) findViewById(R.id.lyt_suggestion);
        et_search = (EditText) findViewById(R.id.et_search);
        bt_clear = (ImageButton) findViewById(R.id.bt_clear);
        bt_clear.setVisibility(View.GONE);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerSuggestion = (RecyclerView) findViewById(R.id.recyclerSuggestion);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        recyclerSuggestion.setLayoutManager(new LinearLayoutManager(this));
        recyclerSuggestion.setHasFixedSize(true);

        et_search.addTextChangedListener(textWatcher);


        failed_snackbar = Snackbar.make(parent_view, "", Snackbar.LENGTH_INDEFINITE).setAction(R.string.retry_txt, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchAction(failed_page);
            }
        });

        //set data and list adapter
        mAdapter = new AdapterPostList(this, recyclerView, new ArrayList<Post>());
        recyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new AdapterPostList.OnItemClickListener() {
            @Override
            public void onItemClick(View v, Post obj, int position) {
                if (obj.type.equalsIgnoreCase("post")) {
                    ActivityPostDetails.navigate(ActivitySearch.this, v.findViewById(R.id.image), obj);
                } else if (obj.type.equalsIgnoreCase("page")) {
                    Page page = new Page(obj);
                    ActivityPageDetails.navigate(ActivitySearch.this, v.findViewById(R.id.image), page);
                }
            }
        });


        // detect when scroll reach bottom
        mAdapter.setOnLoadMoreListener(new AdapterPostList.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int current_page) {
                if (post_total > mAdapter.getItemCount() && current_page != 0) {
                    int next_page = current_page + 1;
                    searchAction(next_page);
                } else {
                    mAdapter.setLoaded();
                }
            }
        });

        //set data and list adapter suggestion
        mAdapterSuggestion = new AdapterSuggestionSearch(this);
        recyclerSuggestion.setAdapter(mAdapterSuggestion);
        showSuggestionSearch();
        mAdapterSuggestion.setOnItemClickListener(new AdapterSuggestionSearch.OnItemClickListener() {
            @Override
            public void onItemClick(View view, String viewModel, int pos) {
                et_search.setText(viewModel);
                lyt_suggestion.setVisibility(View.GONE);
                hideKeyboard();
                searchAction(1);
            }
        });

        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_search.setText("");
            }
        });

        et_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    hideKeyboard();
                    searchAction(1);
                    return true;
                }
                return false;
            }
        });

        et_search.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                showSuggestionSearch();
                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                return false;
            }
        });

    }

    private void initToolbar() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeButtonEnabled(true);
        actionBar.setTitle("");

        // for system bar in lollipop
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(getResources().getColor(R.color.grey_medium));
        }
    }

    TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence c, int i, int i1, int i2) {
            if (c.toString().trim().length() == 0) {
                bt_clear.setVisibility(View.GONE);
            } else {
                bt_clear.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void beforeTextChanged(CharSequence c, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    private void requestSearchApi(final int page_no, final String query) {
        API api = RestAdapter.createAPI();
        callbackCall = api.getSearchPosts(query, page_no, Constant.MAX_SEARCH_RESULT);
        callbackCall.enqueue(new Callback<CallbackListPost>() {
            @Override
            public void onResponse(Call<CallbackListPost> call, Response<CallbackListPost> response) {
                CallbackListPost resp = response.body();
                if (resp != null && resp.status.equals("ok")) {
                    post_total = resp.count_total;
                    displayApiResult(resp.posts);
                } else {
                    onFailRequest(page_no);
                }
            }

            @Override
            public void onFailure(Call<CallbackListPost> call, Throwable t) {
                if (!call.isCanceled()) onFailRequest(page_no);
            }

        });
    }

    private void displayApiResult(final List<Post> posts) {
        mAdapter.insertData(posts);
        progressBar.setVisibility(View.GONE);
        if (mAdapter.getItemCount() == 0) showNotFoundView(true);
    }

    private void onFailRequest(int page_no) {
        failed_page = page_no;
        mAdapter.setLoaded();
        progressBar.setVisibility(View.GONE);
        if (NetworkCheck.isConnect(this)) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.no_internet_text));
        }
    }

    private void searchAction(final int page_no) {
        lyt_suggestion.setVisibility(View.GONE);
        showFailedView(false, "");
        showNotFoundView(false);
        query = et_search.getText().toString().trim();
        if (!query.equals("")) {
            if (page_no == 1) {
                mAdapterSuggestion.addSearchHistory(query);
                mAdapter.resetListData();
                progressBar.setVisibility(View.VISIBLE);
            } else {
                mAdapter.setLoading();
            }
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    requestSearchApi(page_no, query);
                }
            }, Constant.DELAY_TIME);
        } else {
            Toast.makeText(this, R.string.msg_search_input, Toast.LENGTH_SHORT).show();
        }
    }

    private void showSuggestionSearch() {
        mAdapterSuggestion.refreshItems();
        lyt_suggestion.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void showFailedView(boolean show, String message) {
        failed_snackbar.setText(message);
        if (show) {
            failed_snackbar.show();
        } else {
            failed_snackbar.dismiss();
        }
    }

    private void showNotFoundView(boolean show) {
        View lyt_no_item = (View) findViewById(R.id.lyt_no_item);
        ((TextView) findViewById(R.id.no_item_message)).setText(R.string.no_post_found);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            lyt_no_item.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            lyt_no_item.setVisibility(View.GONE);
        }
    }

}
