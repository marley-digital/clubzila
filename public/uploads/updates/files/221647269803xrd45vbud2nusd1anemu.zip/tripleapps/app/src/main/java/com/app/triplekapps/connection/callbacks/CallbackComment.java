package com.app.triplekapps.connection.callbacks;

public class CallbackComment {
    public String status = "";
    public int id = -1;
    public String name = "";
    public String url = "";
    public String date = "";
    public String content = "";
    public int parent = -1;
}
