package com.app.triplekapps;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.multidex.MultiDex;
import android.text.TextUtils;
import android.util.Log;

import com.app.triplekapps.connection.API;
import com.app.triplekapps.connection.RestAdapter;
import com.app.triplekapps.connection.callbacks.CallbackDevice;
import com.app.triplekapps.data.AppConfig;
import com.app.triplekapps.data.SharedPref;
import com.app.triplekapps.model.DeviceInfo;
import com.app.triplekapps.utils.NetworkCheck;
import com.app.triplekapps.utils.Tools;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ThisApplication extends Application {

    private Call<CallbackDevice> callbackCall = null;
    private static ThisApplication mInstance;
    private SharedPref sharedPref;
    private FirebaseAnalytics firebaseAnalytics;

    private int fcm_count = 0;
    private final int FCM_MAX_COUNT = 10;

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        sharedPref = new SharedPref(this);

        // initialize firebase
        FirebaseApp.initializeApp(this);

        // initialize admob
        MobileAds.initialize(this, getString(R.string.admob_app_id));

        // obtain regId & registering device to server
        obtainFirebaseToken();

        // activate analytics tracker
        getFirebaseAnalytics();
        subscribeTopicNotif();

        // get enabled controllers
        Tools.requestInfoApi(this);

        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(false)
                .init();


    }

    public static synchronized ThisApplication getInstance() {
        return mInstance;
    }

    private void obtainFirebaseToken() {
        Log.d("FCM_SUBMIT", "obtainFirebaseToken");
        if (NetworkCheck.isConnect(this) && sharedPref.isOpenAppCounterReach()) {
            fcm_count++;

            Task<InstanceIdResult> resultTask = FirebaseInstanceId.getInstance().getInstanceId();
            resultTask.addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
                @Override
                public void onSuccess(InstanceIdResult instanceIdResult) {

                    Log.d("FCM_SUBMIT", "obtainFirebaseToken : " + fcm_count + "onSuccess");
                    String regId = instanceIdResult.getToken();
                    sharedPref.setFcmRegId(regId);
                    if (!TextUtils.isEmpty(regId)) sendRegistrationToServer(regId);
                }
            });

            resultTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("FCM_SUBMIT", "obtainFirebaseToken : " + fcm_count + "-onFailure : " + e.getMessage());
                    if (fcm_count > FCM_MAX_COUNT) return;
                    obtainFirebaseToken();
                }
            });
        }
    }

    private void sendRegistrationToServer(String token) {

        Log.d("FCM_SUBMIT", "sendRegistrationToServer : " + token);
        API api = RestAdapter.createAPI();
        DeviceInfo deviceInfo = Tools.getDeviceInfo(this);
        deviceInfo.regid = token;

        callbackCall = api.registerDevice(deviceInfo);
        callbackCall.enqueue(new Callback<CallbackDevice>() {
            @Override
            public void onResponse(Call<CallbackDevice> call, Response<CallbackDevice> response) {
                CallbackDevice resp = response.body();
                if (resp != null && resp.status.equals("success")) {
                    sharedPref.setOpenAppCounter(0);
                    Log.d("FCM_SUBMIT", "sendRegistrationToServer : onResponse : success");
                } else {
                    Log.d("FCM_SUBMIT", "sendRegistrationToServer : onResponse : not success");
                }
            }

            @Override
            public void onFailure(Call<CallbackDevice> call, Throwable t) {
                Log.d("FCM_SUBMIT", "sendRegistrationToServer : onFailure : " + t.getMessage());
            }

        });
    }


    private void subscribeTopicNotif() {
        if (sharedPref.isSubscibeNotif()) return;
        FirebaseMessaging.getInstance().subscribeToTopic("ALL-DEVICE").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                sharedPref.setSubscibeNotif(task.isSuccessful());
            }
        });
    }

    /**
     * ---------------------------------------------------------------------------------------------
     * For Google Analytics
     */
    public synchronized FirebaseAnalytics getFirebaseAnalytics() {
        if (firebaseAnalytics == null && AppConfig.ENABLE_ANALYTICS) {
            // Obtain the Firebase Analytics.
            firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        }
        return firebaseAnalytics;
    }

    public void trackScreenView(String event) {
        if (firebaseAnalytics == null || !AppConfig.ENABLE_ANALYTICS) return;
        Bundle params = new Bundle();
        event = event.replaceAll("[^A-Za-z0-9_]", "");
        params.putString("event", event);
        firebaseAnalytics.logEvent(event, params);
    }

    public void trackEvent(String category, String action, String label) {
        if (firebaseAnalytics == null || !AppConfig.ENABLE_ANALYTICS) return;
        Bundle params = new Bundle();
        category = category.replaceAll("[^A-Za-z0-9_]", "");
        action = action.replaceAll("[^A-Za-z0-9_]", "");
        label = label.replaceAll("[^A-Za-z0-9_]", "");
        params.putString("category", category);
        params.putString("action", action);
        params.putString("label", label);
        firebaseAnalytics.logEvent("EVENT", params);
    }

    /** ---------------------------------------- End of analytics ----------------------------------
     * */
}
