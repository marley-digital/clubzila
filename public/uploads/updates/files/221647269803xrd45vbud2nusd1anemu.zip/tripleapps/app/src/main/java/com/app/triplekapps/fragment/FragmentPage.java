package com.app.triplekapps.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.triplekapps.ActivityMain;
import com.app.triplekapps.ActivityPageDetails;
import com.app.triplekapps.R;
import com.app.triplekapps.adapter.AdapterPageList;
import com.app.triplekapps.connection.API;
import com.app.triplekapps.connection.RestAdapter;
import com.app.triplekapps.connection.callbacks.CallbackListPage;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.model.Page;
import com.app.triplekapps.utils.NetworkCheck;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentPage extends Fragment {

    private View root_view, parent_view;
    private RecyclerView recyclerView;
    private AdapterPageList mAdapter;
    private SwipeRefreshLayout swipe_refresh;
    private Call<CallbackListPage> callbackCall = null;

    private Snackbar failed_snackbar;
    private int post_total = 0;
    private int failed_page = 0;
    String include_ids;
    String exclude_ids;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root_view = inflater.inflate(R.layout.fragment_page, null);
        parent_view = getActivity().findViewById(R.id.main_content);

        swipe_refresh = root_view.findViewById(R.id.swipe_refresh_layout_page);
        recyclerView = root_view.findViewById(R.id.recyclerViewPage);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        //set data and list adapter
        mAdapter = new AdapterPageList(getActivity(), recyclerView, new ArrayList<Page>());
        recyclerView.setAdapter(mAdapter);

        // on item list clicked
        mAdapter.setOnItemClickListener(new AdapterPageList.OnItemClickListener() {
            @Override
            public void onItemClick(View v, Page obj, int position) {
                ActivityPageDetails.navigate((ActivityMain) getActivity(), v.findViewById(R.id.image), obj);
            }
        });

        // detect when scroll reach bottom
        mAdapter.setOnLoadMoreListener(new AdapterPageList.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int current_page) {
                if (post_total > mAdapter.getItemCount() && current_page != 0) {
                    int next_page = current_page + 1;
                    requestAction(next_page);
                } else {
                    mAdapter.setLoaded();
                }
            }
        });

        // on swipe list
        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (callbackCall != null && callbackCall.isExecuted()) callbackCall.cancel();
                mAdapter.resetListData();
                requestAction(1);
            }
        });

        failed_snackbar = Snackbar.make(parent_view, "", Snackbar.LENGTH_INDEFINITE).setAction(R.string.retry_txt, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction(failed_page);
            }
        });

        include_ids = TextUtils.join(",", getResources().getStringArray(R.array.page_id_filter));
        exclude_ids = TextUtils.join(",", getResources().getStringArray(R.array.page_id_display));

        requestAction(1);

        return root_view;
    }

    private void displayApiResult(final List<Page> posts) {
        mAdapter.insertData(posts);
        swipeProgress(false);
        if (posts.size() == 0) {
            showNoItemView(true);
        }
    }

    private void requestListPostApi(final int page_no) {
        API api = RestAdapter.createAPI();
        callbackCall = api.getPagesByPage(page_no, Constant.PAGE_PER_REQUEST, include_ids, exclude_ids);
        callbackCall.enqueue(new Callback<CallbackListPage>() {
            @Override
            public void onResponse(Call<CallbackListPage> call, Response<CallbackListPage> response) {
                CallbackListPage resp = response.body();
                if (resp != null && resp.status.equals("ok")) {
                    post_total = resp.count_total;
                    displayApiResult(resp.posts);
                } else {
                    onFailRequest(page_no);
                }
            }

            @Override
            public void onFailure(Call<CallbackListPage> call, Throwable t) {
                if (!call.isCanceled()) onFailRequest(page_no);
            }

        });
    }

    private void onFailRequest(int page_no) {
        failed_page = page_no;
        mAdapter.setLoaded();
        swipeProgress(false);
        if (NetworkCheck.isConnect(getActivity())) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.no_internet_text));
        }
    }

    private void requestAction(final int page_no) {
        showFailedView(false, "");
        showNoItemView(false);
        if (page_no == 1) {
            swipeProgress(true);
        } else {
            mAdapter.setLoading();
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                requestListPostApi(page_no);
            }
        }, Constant.DELAY_TIME);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        if (callbackCall != null && callbackCall.isExecuted()) {
            callbackCall.cancel();
        }
        if(failed_snackbar.isShown()) failed_snackbar.dismiss();
    }

    private void showFailedView(boolean show, String message) {
        failed_snackbar.setText(message);
        if (show) {
            failed_snackbar.show();
        } else {
            failed_snackbar.dismiss();
        }
    }

    private void showNoItemView(boolean show) {
        View lyt_no_item = (View) root_view.findViewById(R.id.lyt_no_item_page);
        ((TextView) root_view.findViewById(R.id.no_item_message)).setText(R.string.no_post);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            lyt_no_item.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            lyt_no_item.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(final boolean show) {
        if (!show) {
            swipe_refresh.setRefreshing(show);
            return;
        }
        swipe_refresh.post(new Runnable() {
            @Override
            public void run() {
                swipe_refresh.setRefreshing(show);
            }
        });
    }

}