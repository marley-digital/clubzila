package com.app.triplekapps.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.app.triplekapps.ActivityMain;
import com.app.triplekapps.ActivityPostDetails;
import com.app.triplekapps.R;
import com.app.triplekapps.adapter.AdapterHome;
import com.app.triplekapps.connection.API;
import com.app.triplekapps.connection.RestAdapter;
import com.app.triplekapps.connection.callbacks.CallbackListPost;
import com.app.triplekapps.data.Constant;
import com.app.triplekapps.model.Post;
import com.app.triplekapps.utils.NetworkCheck;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.app.triplekapps.ActivityMain.ShowMaxInterstitialAd;

public class FragmentHome extends Fragment {

    private View root_view, parent_view;
    private RecyclerView recyclerView;
    private AdapterHome mAdapter;
    private SwipeRefreshLayout swipe_refresh;
    private Call<CallbackListPost> callbackHeader = null;
    private Call<CallbackListPost> callbackPosts = null;
    private List<Post> sticky_posts;
    private List<Post> posts;
    private Snackbar failed_snackbar;

    private boolean is_request_post_finish = false;
    private boolean is_request_sticky_finish = false;
    private int post_total = 0;
    private int failed_page = 0;
    private int page_no = -1;

   com.google.android.gms.ads.interstitial.InterstitialAd mInterstitialAd;





    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root_view = inflater.inflate(R.layout.fragment_home, null);
        parent_view = getActivity().findViewById(R.id.main_content);

        swipe_refresh = root_view.findViewById(R.id.swipe_refresh_layout_home);
        recyclerView = root_view.findViewById(R.id.recyclerViewHome);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),1));
        recyclerView.setHasFixedSize(true);
//        interstitialAd = new com.facebook.ads.InterstitialAd(getActivity(),getActivity().getResources().getString(R.string.interitialhome2));

//
//
//        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
//            @Override
//            public void onInterstitialDisplayed(Ad ad) {
//
//            }
//
//            @Override
//            public void onInterstitialDismissed(Ad ad) {
//
//                interstitialAd.loadAd();
//
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//
//            }
//        };
//        interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());
//
//
//        interstitialAd.loadAd(interstitialAd.buildLoadAdConfig().withAdListener(interstitialAdListener).build());


        AdRequest adRequest = new AdRequest.Builder().build();

        com.google.android.gms.ads.interstitial.InterstitialAd.load(getActivity(),getResources().getString(R.string.admob_interAd), adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd admobinterstitialAd) {
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                mInterstitialAd = admobinterstitialAd;
                //Log.i(TAG, "onAdLoaded");

                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        AdRequest adRequest = new AdRequest.Builder().build();

                        com.google.android.gms.ads.interstitial.InterstitialAd.load(getActivity(),getResources().getString(R.string.admob_interAd), adRequest, new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull com.google.android.gms.ads.interstitial.InterstitialAd interstitialAd) {
                                // The mInterstitialAd reference will be null until
                                // an ad is loaded.
                                mInterstitialAd = interstitialAd;
                                // Log.i(TAG, "onAdLoaded");
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                // Handle the error
                                //  Log.i(TAG, loadAdError.getMessage());
                                mInterstitialAd = null;
                            }
                        });
                        // Called when fullscreen content is dismissed.
                        // Log.d("TAG", "The ad was dismissed.");
                    }



                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
                        mInterstitialAd = null;
                        //   Log.d("TAG", "The ad was shown.");
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                // Handle the error
                //  Log.i(TAG, loadAdError.getMessage());
                mInterstitialAd = null;
            }
        });




        //set data and list adapter

        mAdapter = new AdapterHome(getActivity(), recyclerView, new ArrayList<Post>());


//        FBNativeAdAdapter fbAdapter = FBNativeAdAdapter.Builder.with(getString(R.string.native_id), mAdapter).build();
        recyclerView.setAdapter(mAdapter);


        //recyclerView.setAdapter(mAdapter);

        // on item list clicked
        mAdapter.setOnItemClickListener(new AdapterHome.OnItemClickListener() {
            @Override
            public void onItemClick(View v, Post obj, int position) {
                if (v == null) {
                    ActivityPostDetails.navigate((ActivityMain) getActivity(), obj);
                } else {
                    ActivityPostDetails.navigate((ActivityMain) getActivity(), v.findViewById(R.id.image), obj);
                }

                 if(position%2!=0){
                     ShowMaxInterstitialAd();
                 } else
                     if(mInterstitialAd!=null){
                         mInterstitialAd.show(getActivity());
                     }
              /*  if(mInterstitialAd!=null){

                    mInterstitialAd.show(getActivity());



                }

*/


            }
        });

        // detect when scroll reach bottom
        mAdapter.setOnLoadMoreListener(new AdapterHome.OnLoadMoreListener() {
            @Override
            public void onLoadMore(int current_page) {
                boolean is_load_all = mAdapter.getPostCount() > post_total;
                if (!is_load_all && current_page != 0) {
                    int next_page = current_page + 1;
                    requestAction(next_page, false);
                } else {
                    mAdapter.setLoaded();
                }
            }
        });

        // on swipe list
        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (callbackPosts != null && callbackPosts.isExecuted()) callbackPosts.cancel();
                if (callbackPosts != null && callbackPosts.isExecuted()) callbackPosts.cancel();
                is_request_post_finish = false;
                is_request_sticky_finish = false;
                requestAction(1, true);
            }
        });
        failed_snackbar = Snackbar.make(parent_view, "", Snackbar.LENGTH_INDEFINITE).setAction(R.string.retry_txt, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestAction(failed_page, true);
            }
        });

        requestAction(1, true);

        return root_view;
    }


    private void displayApiResult(final List<Post> items) {
        if (page_no == 1 && is_request_post_finish && is_request_sticky_finish) {
            mAdapter.resetListData();
            if (sticky_posts != null && sticky_posts.size() > 0) {
                mAdapter.setSlider(sticky_posts);
            }
            mAdapter.insertData(posts);
            swipeProgress(false);
        } else if (items != null) {
            mAdapter.insertData(items);
        }
    }

    private void requestListSticky() {
        API api = RestAdapter.createAPI();
        callbackHeader = api.getStickyPost();
        callbackHeader.enqueue(new Callback<CallbackListPost>() {
            @Override
            public void onResponse(Call<CallbackListPost> call, Response<CallbackListPost> response) {
                CallbackListPost resp = response.body();
                is_request_sticky_finish = true;
                if (resp != null && resp.status.equals("ok")) {
                    sticky_posts = resp.posts;
                    displayApiResult(null);
                }
            }

            @Override
            public void onFailure(Call<CallbackListPost> call, Throwable t) {
                if (!call.isCanceled()) onFailRequest(page_no);
            }
        });
    }

    private void requestListPostApi(final int page_no) {
        API api = RestAdapter.createAPI();
        callbackPosts = api.getPostByPage(page_no, Constant.POST_PER_REQUEST);
        callbackPosts.enqueue(new Callback<CallbackListPost>() {
            @Override
            public void onResponse(Call<CallbackListPost> call, Response<CallbackListPost> response) {
                CallbackListPost resp = response.body();
                is_request_post_finish = true;
                if (resp != null && resp.status.equals("ok")) {
                    post_total = resp.count_total;
                    posts = resp.posts;
                    displayApiResult(resp.posts);
                } else {
                    onFailRequest(page_no);
                }
            }

            @Override
            public void onFailure(Call<CallbackListPost> call, Throwable t) {
                if (!call.isCanceled()) onFailRequest(page_no);
            }

        });
    }

    private void onFailRequest(int page_no) {
        failed_page = page_no;
        mAdapter.setLoaded();
        swipeProgress(false);
        if (NetworkCheck.isConnect(getActivity())) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.no_internet_text));
        }
    }

    private void requestAction(final int page_no, boolean load_header) {
        showFailedView(false, "");
        this.page_no = page_no;
        if (page_no == 1 && load_header) {
            mAdapter.resetListData();
            requestListSticky();
            swipeProgress(true);
        } else {
            mAdapter.setLoading();
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                requestListPostApi(page_no);
            }
        }, 500);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
      /*  if (interstitialAd != null) {
            interstitialAd.destroy();
        }*/
        swipeProgress(false);
        if (callbackPosts != null && callbackPosts.isExecuted()) {
            callbackPosts.cancel();
        }
        if (callbackHeader != null && callbackHeader.isExecuted()) {
            callbackHeader.cancel();
        }
        if(failed_snackbar.isShown()) failed_snackbar.dismiss();
    }

    private void showFailedView(boolean show, String message) {
        failed_snackbar.setText(message);
        if (show) {
            failed_snackbar.show();
        } else {
            failed_snackbar.dismiss();
        }
    }

    private void swipeProgress(final boolean show) {
        if (!show) {
            swipe_refresh.setRefreshing(show);
            return;
        }
        swipe_refresh.post(new Runnable() {
            @Override
            public void run() {
                swipe_refresh.setRefreshing(show);
            }
        });
    }

}

