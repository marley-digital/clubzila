package com.app.triplekapps.room.table;

import com.app.triplekapps.model.Post;
import com.google.gson.annotations.Expose;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "post")
public class PostEntity {

    @PrimaryKey
    public long id = -1;

    @Expose
    @ColumnInfo(name = "type")
    public String type = "";

    @Expose
    @ColumnInfo(name = "slug")
    public String slug = "";

    @Expose
    @ColumnInfo(name = "url")
    public String url = "";

    @Expose
    @ColumnInfo(name = "status")
    public String status = "";

    @Expose
    @ColumnInfo(name = "title")
    public String title = "";

    @Expose
    @ColumnInfo(name = "title_plain")
    public String title_plain = "";

    @Expose
    @ColumnInfo(name = "content")
    public String content = "";

    @Expose
    @ColumnInfo(name = "excerpt")
    public String excerpt = "";

    @Expose
    @ColumnInfo(name = "date")
    public String date = "";

    @Expose
    @ColumnInfo(name = "modified")
    public String modified = "";

    @Expose
    @ColumnInfo(name = "thumbnail")
    public String thumbnail = "";

    @Expose
    @ColumnInfo(name = "comment_count")
    public long comment_count = -1;

    @Expose
    @ColumnInfo(name = "saved_date")
    public long saved_date = -1;

    public PostEntity() {
    }

    public static PostEntity entity(Post post) {
        PostEntity entity = new PostEntity();
        entity.id = post.id;
        entity.type = post.type;
        entity.slug = post.slug;
        entity.url = post.url;
        entity.status = post.status;
        entity.title = post.title;
        entity.title_plain = post.title_plain;
        entity.content = post.content;
        entity.excerpt = post.excerpt;
        entity.date = post.date;
        entity.modified = post.modified;
        entity.thumbnail = post.thumbnail;
        entity.comment_count = post.comment_count;
        return entity;
    }

    public Post original() {
        Post post = new Post();
        post.id = id;
        post.type = type;
        post.slug = slug;
        post.url = url;
        post.status = status;
        post.title = title;
        post.title_plain = title_plain;
        post.content = content;
        post.excerpt = excerpt;
        post.date = date;
        post.modified = modified;
        post.thumbnail = thumbnail;
        post.comment_count = comment_count;
        return post;
    }
}
