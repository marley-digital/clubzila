package com.app.triplekapps.connection.callbacks;

public class CallbackDevice {
    public String status = "";
    public String message = "";
}
