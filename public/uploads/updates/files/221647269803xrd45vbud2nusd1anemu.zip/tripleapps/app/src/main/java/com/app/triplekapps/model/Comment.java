package com.app.triplekapps.model;

import java.io.Serializable;

public class Comment implements Serializable {

    public Long id = -1L;
    public String name = "";
    public String url = "";
    public String date = "";
    public String content = "";
    public long parent = -1;

}
