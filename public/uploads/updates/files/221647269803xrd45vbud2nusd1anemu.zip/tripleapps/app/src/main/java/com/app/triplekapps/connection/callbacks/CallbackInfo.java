package com.app.triplekapps.connection.callbacks;

import java.util.ArrayList;
import java.util.List;

public class CallbackInfo {

    public String status = "";
    public String json_api_version = "";
    public List<String> controllers = new ArrayList<>();
}
