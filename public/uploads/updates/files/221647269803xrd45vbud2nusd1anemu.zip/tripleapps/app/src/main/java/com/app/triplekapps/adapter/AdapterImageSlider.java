package com.app.triplekapps.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.triplekapps.R;
import com.app.triplekapps.model.Post;
import com.app.triplekapps.utils.Tools;

import java.util.List;

import androidx.viewpager.widget.PagerAdapter;

public class AdapterImageSlider extends PagerAdapter {

    private Context context;
    private List<Post> items;

    public AdapterImageSlider.OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(View view, Post obj);
    }

    public void setOnItemClickListener(AdapterImageSlider.OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public AdapterImageSlider(Context context, List<Post> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return this.items.size();
    }

    public Post getItem(int pos) {
        return items.get(pos);
    }

    public void setItems(List<Post> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        final Post o = items.get(position);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.item_slider_sticky, container, false);

        ImageView image = v.findViewById(R.id.image);
        TextView title = v.findViewById(R.id.title);
        TextView date = v.findViewById(R.id.date);
        View lyt_parent = v.findViewById(R.id.lyt_parent);
        date.setText(Tools.getFormatedDateSimple(o.date));
        title.setText(Html.fromHtml(o.title));
        Tools.displayImage(context, o.thumbnail, image);
        lyt_parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(v, o);
                }
            }
        });

        (container).addView(v);

        return v;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        (container).removeView((View) object);

    }

}